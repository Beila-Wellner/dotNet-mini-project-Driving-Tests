﻿using System;
//by Neomi Mayer 328772801 and Beila Wellner 205823792
namespace BE
{
    public enum Gender { Male, Female, Other };
    public enum CarType { Private, TwoWheel, MediumTruck, HeavyTruck };
    public enum GearType { Manual, Automatic };
    
}
